import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import CodeEditor from './components/CodeEditor';
import PromptLibrary from './components/PromptLibrary';
import { SNIPPETS } from './languages';

const STORAGE_KEY = 'polycode.codes.v1';
const SNIPPET_COUNT = Object.keys(SNIPPETS).length;

function loadCodes() {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    const saved = raw ? JSON.parse(raw) : {};
    return Object.fromEntries(
      Object.entries(SNIPPETS).map(([id, sample]) => [
        id,
        typeof saved[id] === 'string' && saved[id].trim() ? saved[id] : sample,
      ])
    );
  } catch {
    return { ...SNIPPETS };
  }
}

function formatDuration(ms) {
  if (typeof ms !== 'number' || Number.isNaN(ms)) return '—';
  return ms >= 1000 ? `${(ms / 1000).toFixed(2)} s` : `${ms} ms`;
}

function PlayIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true">
      <path d="M8 5.14v13.72a1 1 0 0 0 1.53.85l10.3-6.86a1 1 0 0 0 0-1.7L9.53 4.29A1 1 0 0 0 8 5.14Z" />
    </svg>
  );
}

function TerminalIcon() {
  return (
    <svg viewBox="0 0 24 24" width="46" height="46" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <rect x="2.5" y="4" width="19" height="16" rx="3" />
      <path d="m7 9 3 3-3 3M13 15h4" />
    </svg>
  );
}

function BrandMark() {
  return (
    <svg viewBox="0 0 48 48" width="26" height="26" fill="none" stroke="currentColor" strokeWidth="3.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M18 16 10 24l8 8M30 16l8 8-8 8M27 12l-6 24" />
    </svg>
  );
}

export default function App() {
  const [view, setView] = useState('code');
  const [catalog, setCatalog] = useState([]);
  const [status, setStatus] = useState('loading');
  const [reloadKey, setReloadKey] = useState(0);
  const [activeId, setActiveId] = useState('javascript');
  const [codes, setCodes] = useState(loadCodes);
  const [stdin, setStdin] = useState('');
  const stdinRef = useRef(null);
  const [lineInput, setLineInput] = useState('');
  const sessionRef = useRef(null);
  const outputRef = useRef(null);
  const [result, setResult] = useState(null);
  const [running, setRunning] = useState(false);
  const [resetToken, setResetToken] = useState(0);
  const [toast, setToast] = useState('');
  const [shareOpen, setShareOpen] = useState(false);
  const [shareLink, setShareLink] = useState('');
  const [sharing, setSharing] = useState(false);

  const activeMeta = useMemo(
    () => catalog.find((item) => item.id === activeId) || null,
    [catalog, activeId]
  );
  const availableCount = catalog.filter((item) => item.available).length;
  const expectsStdin = useMemo(
    () =>
      /(\binput\s*\(|\bscanf\s*\(|\bcin\s*>>|\bScanner\b|sys\.stdin|\bgets\b|readline\s*\(|Console\.ReadLine)/.test(
        codes[activeId] || ''
      ),
    [codes, activeId]
  );
  const canRun =
    status === 'ready' && Boolean(activeMeta?.available) && !running && Boolean(codes[activeId]);

  useEffect(() => {
    let cancelled = false;
    setStatus('loading');
    fetch('/api/languages')
      .then((res) => {
        if (!res.ok) throw new Error('bad response');
        return res.json();
      })
      .then((data) => {
        if (cancelled) return;
        setCatalog(Array.isArray(data.languages) ? data.languages : []);
        setStatus('ready');
      })
      .catch(() => {
        if (!cancelled) setStatus('offline');
      });
    return () => {
      cancelled = true;
    };
  }, [reloadKey]);

  useEffect(() => {
    const timer = setTimeout(() => {
      try {
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(codes));
      } catch {
        /* 忽略存储异常 */
      }
    }, 250);
    return () => clearTimeout(timer);
  }, [codes]);

  const showToast = useCallback((message) => {
    setToast(message);
  }, []);

  // 移动端页面会整页滚动，切换视图时回到顶部
  useEffect(() => {
    window.scrollTo(0, 0);
    document.body.scrollTop = 0;
  }, [view]);

  useEffect(() => {
    if (!toast) return undefined;
    const timer = setTimeout(() => setToast(''), 1800);
    return () => clearTimeout(timer);
  }, [toast]);

  useEffect(() => {
    const node = outputRef.current;
    if (node) node.scrollTop = node.scrollHeight;
  }, [result?.stdout, result?.stderr]);

  const updateCode = useCallback(
    (next) => {
      setCodes((prev) => ({ ...prev, [activeId]: next }));
    },
    [activeId]
  );

  const applyEvent = useCallback((event) => {
    setResult((prev) => {
      const base =
        prev || {
          ok: true,
          phase: 'run',
          stdout: '',
          stderr: '',
          exitCode: null,
          durationMs: 0,
          running: true,
          statusText: '',
        };

      if (event.type === 'stdout') return { ...base, stdout: base.stdout + event.text };
      if (event.type === 'stderr') return { ...base, stderr: base.stderr + event.text };
      if (event.type === 'status') return { ...base, statusText: event.text };
      if (event.type === 'exit') {
        return {
          ...base,
          ok: event.exitCode === 0 && !event.timedOut,
          exitCode: event.exitCode,
          durationMs: event.durationMs,
          timedOut: Boolean(event.timedOut),
          truncated: Boolean(event.truncated),
          phase: event.compileFailed ? 'compile' : 'run',
          running: false,
          statusText: '',
        };
      }
      return base;
    });
  }, []);

  const run = useCallback(async () => {
    if (running) return;
    const code = codes[activeId];
    if (!code) return;

    setRunning(true);
    setResult({
      ok: true,
      phase: 'run',
      stdout: '',
      stderr: '',
      exitCode: null,
      durationMs: 0,
      running: true,
      statusText: '',
    });

    try {
      const startRes = await fetch('/api/sessions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ language: activeId, code, stdin }),
      });
      const started = await startRes.json();
      if (!startRes.ok) throw new Error(started.error || '执行请求失败');

      sessionRef.current = started.id;
      const streamRes = await fetch(`/api/sessions/${started.id}/events`);
      if (!streamRes.ok || !streamRes.body) throw new Error('无法建立输出流');

      const reader = streamRes.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        let index = buffer.indexOf('\n');
        while (index >= 0) {
          const line = buffer.slice(0, index).trim();
          buffer = buffer.slice(index + 1);
          if (line) {
            try {
              applyEvent(JSON.parse(line));
            } catch {
              /* 忽略不完整的行 */
            }
          }
          index = buffer.indexOf('\n');
        }
      }

      // 输出流已结束但没有收到 exit 事件（例如后端重启）
      setResult((prev) =>
        prev?.running
          ? { ...prev, ok: false, running: false, stderr: prev.stderr || '执行流已中断' }
          : prev
      );
    } catch (error) {
      setResult({
        ok: false,
        phase: 'run',
        stdout: '',
        stderr:
          error?.message === 'Failed to fetch'
            ? '无法连接到执行服务，请确认后端已启动（npm run dev）。'
            : `执行失败：${error?.message || '未知错误'}`,
        exitCode: null,
        durationMs: 0,
      });
    } finally {
      sessionRef.current = null;
      setRunning(false);
    }
  }, [activeId, applyEvent, codes, running, stdin]);

  const sendLine = useCallback(async () => {
    const id = sessionRef.current;
    if (!id) return;
    const text = lineInput;
    setLineInput('');
    try {
      const res = await fetch(`/api/sessions/${id}/input`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data: `${text}\n` }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        showToast(data.error || '发送输入失败');
      }
    } catch {
      showToast('发送失败，执行服务可能已断开');
    }
  }, [lineInput, showToast]);

  const stopRun = useCallback(async () => {
    const id = sessionRef.current;
    if (!id) return;
    try {
      await fetch(`/api/sessions/${id}/stop`, { method: 'POST' });
    } catch {
      /* ignore */
    }
  }, []);

  const handleShare = useCallback(async () => {
    if (sharing) return;
    setSharing(true);
    try {
      const res = await fetch('/api/shares', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ language: activeId, code: codes[activeId], stdin }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || '生成分享链接失败');

      const link = `${window.location.origin}${data.path}`;
      setShareLink(link);
      setShareOpen(true);
      try {
        await navigator.clipboard.writeText(link);
        showToast('分享链接已复制');
      } catch {
        /* 弹窗内可手动复制 */
      }
    } catch (error) {
      showToast(error?.message || '生成分享链接失败');
    } finally {
      setSharing(false);
    }
  }, [activeId, codes, sharing, showToast, stdin]);

  const copyShareLink = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(shareLink);
      showToast('分享链接已复制');
    } catch {
      showToast('复制失败，请手动选择链接');
    }
  }, [shareLink, showToast]);

  // 打开 /s/<id> 分享链接时载入对应代码
  useEffect(() => {
    const match = window.location.pathname.match(/^\/s\/([A-Za-z0-9]+)\/?$/);
    if (!match) return undefined;

    let cancelled = false;
    fetch(`/api/shares/${match[1]}`)
      .then((res) => {
        if (!res.ok) throw new Error('分享链接不存在或已失效');
        return res.json();
      })
      .then((data) => {
        if (cancelled) return;
        setActiveId(data.language);
        setCodes((prev) => ({ ...prev, [data.language]: data.code }));
        setStdin(typeof data.stdin === 'string' ? data.stdin : '');
        setResult(null);
        window.history.replaceState({}, '', '/');
        showToast('已载入分享的代码');
      })
      .catch((error) => {
        if (!cancelled) showToast(error?.message || '载入分享代码失败');
      });

    return () => {
      cancelled = true;
    };
  }, [showToast]);

  const handleReset = () => {
    setCodes((prev) => ({ ...prev, [activeId]: SNIPPETS[activeId] }));
    setResetToken((token) => token + 1);
    showToast('已恢复示例代码');
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(codes[activeId] || '');
      showToast('代码已复制');
    } catch {
      showToast('复制失败，请手动选择代码');
    }
  };

  const activeColor = activeMeta?.color || '#6d8bff';

  return (
    <div className="app">
      <div className="aurora" aria-hidden="true">
        <span className="blob blob-a" />
        <span className="blob blob-b" />
        <span className="blob blob-c" />
      </div>
      <div className="grid-overlay" aria-hidden="true" />

      <header className="topbar">
        <div className="brand">
          <span className="brand-mark">
            <BrandMark />
          </span>
          <div className="brand-text">
            <h1>PolyCode</h1>
            <p>多语言在线运行台</p>
          </div>
        </div>

        <nav className="view-switch" aria-label="功能切换">
          <button
            type="button"
            className={`view-btn${view === 'code' ? ' active' : ''}`}
            onClick={() => setView('code')}
          >
            代码运行
          </button>
          <button
            type="button"
            className={`view-btn${view === 'prompts' ? ' active' : ''}`}
            onClick={() => setView('prompts')}
          >
            提示词库
          </button>
        </nav>

        <div className="topbar-right">
          {status === 'offline' ? (
            <button className="status-pill offline" onClick={() => setReloadKey((key) => key + 1)}>
              <span className="dot" />
              执行服务未连接 · 点击重试
            </button>
          ) : (
            <span className={`status-pill ${status}`}>
              <span className="dot" />
              {status === 'loading'
                ? '正在检测本机运行时…'
                : `${availableCount} / ${catalog.length} 个运行时就绪`}
            </span>
          )}
        </div>
      </header>

      {view === 'code' ? (
        <main className="workspace">
        <aside className="card rail">
          <div className="rail-head">
            <span>语言</span>
            <span className="rail-count">{catalog.length || SNIPPET_COUNT}</span>
          </div>
          <div className="rail-list">
            {catalog.length === 0
              ? Array.from({ length: 8 }).map((_, index) => (
                  <div className="rail-skeleton" key={index} />
                ))
              : catalog.map((lang) => {
                  const selected = lang.id === activeId;
                  return (
                    <button
                      key={lang.id}
                      type="button"
                      className={`rail-item${selected ? ' active' : ''}${
                        lang.available ? '' : ' unavailable'
                      }`}
                      style={{ '--lang': lang.color }}
                      onClick={() => {
                        setActiveId(lang.id);
                        setResult(null);
                      }}
                      title={
                        lang.available
                          ? `${lang.name} ${lang.version || ''}`
                          : lang.reason || '本机未安装该运行时'
                      }
                    >
                      <span className="monogram">{lang.monogram}</span>
                      <span className="rail-meta">
                        <span className="rail-name">{lang.name}</span>
                        <span className="rail-version">
                          {lang.available ? lang.version || '已安装' : '未安装'}
                        </span>
                      </span>
                      <span className={`avail-dot${lang.available ? ' on' : ''}`} />
                    </button>
                  );
                })}
          </div>
          <div className="rail-foot">
            <span className="ping" />
            运行时来自本机环境
          </div>
        </aside>

        <section className="card editor-card">
          <div className="pane-head">
            <div className="window-dots" aria-hidden="true">
              <i />
              <i />
              <i />
            </div>
            <span className="file-name">{activeMeta?.fileName || 'main'}</span>
            {activeMeta && (
              <span className="lang-chip" style={{ '--lang': activeColor }}>
                {activeMeta.name}
              </span>
            )}
            <span className="spacer" />
            <button
              type="button"
              className="ghost-btn"
              onClick={handleShare}
              disabled={sharing || !codes[activeId]}
            >
              {sharing ? '生成中…' : '分享'}
            </button>
            <button type="button" className="ghost-btn" onClick={handleCopy}>
              复制
            </button>
            <button type="button" className="ghost-btn" onClick={handleReset}>
              重置示例
            </button>
          </div>

          <CodeEditor
            key={`${activeId}-${resetToken}`}
            languageId={activeId}
            initialCode={codes[activeId] || ''}
            onChange={updateCode}
            onRun={run}
          />

          <div className="editor-foot">
            <span className="shortcut">
              <kbd>Ctrl</kbd>
              <span>/</span>
              <kbd>⌘</kbd>
              <span>+</span>
              <kbd>Enter</kbd>
              <span className="shortcut-label">运行</span>
            </span>
            <div className="foot-actions">
              <button
                type="button"
                className="ghost-btn"
                onClick={() => setResult(null)}
                disabled={!result}
              >
                清空输出
              </button>
              <button type="button" className="run-btn" onClick={run} disabled={!canRun}>
                {running ? <span className="spinner" /> : <PlayIcon />}
                {running ? '运行中…' : '运行代码'}
              </button>
            </div>
          </div>
        </section>

        <aside className="io-col">
          <section className="card stdin-card">
            <div className="card-head">
              <span className="card-title">标准输入</span>
              {expectsStdin ? (
                <span className="card-warn">运行中可在输出区实时输入</span>
              ) : (
                <span className="card-hint">stdin · 可选</span>
              )}
            </div>
            <textarea
              ref={stdinRef}
              className="stdin-area"
              value={stdin}
              onChange={(event) => setStdin(event.target.value)}
              placeholder={
                expectsStdin
                  ? '可预先填写输入内容（每行一个），运行时会自动送入程序…\n例如：\n70\n1.75'
                  : '程序运行时会读取这里的内容…\n例如：\n5 3\n1 2 3 4 5'
              }
              spellCheck={false}
              aria-label="标准输入"
            />
          </section>

          <section className="card output-card">
            <div className="card-head">
              <span className="card-title">输出</span>
              <span className="spacer" />
              {running ? (
                <button type="button" className="ghost-btn danger" onClick={stopRun}>
                  终止
                </button>
              ) : (
                result && (
                  <div className="meta-chips">
                    <span className={`chip ${result.ok ? 'good' : 'bad'}`}>
                      退出码 {result.exitCode === null ? '—' : result.exitCode}
                    </span>
                    <span className="chip">耗时 {formatDuration(result.durationMs)}</span>
                  </div>
                )
              )}
            </div>

            <div className="output-body" ref={outputRef}>
              {!result && !running && (
                <div className="empty-state">
                  <TerminalIcon />
                  <p>点击「运行代码」查看结果</p>
                  <span>
                    {availableCount > 0
                      ? `${availableCount} 个本机运行时可用 · 支持 ${SNIPPET_COUNT} 种语言`
                      : '正在检测本机可用的语言运行时'}
                  </span>
                </div>
              )}

              {running && !result?.stdout && !result?.stderr && (
                <div className="run-state">
                  <span className="spinner large" />
                  <span>{result?.statusText || '正在编译并执行…'}</span>
                </div>
              )}

              {result && !running && result.timedOut && (
                <div className="banner warn">
                  程序超过 30 秒没有响应，已被终止（如需输入，请在运行中直接键入）
                </div>
              )}
              {result && !running && result.truncated && (
                <div className="banner warn">输出内容过多，已被截断</div>
              )}
              {result && !running && result.phase === 'compile' && (
                <div className="banner error">编译未通过，请检查上方代码</div>
              )}

              {result?.stdout && <pre className="stream out">{result.stdout}</pre>}
              {result?.stderr && <pre className="stream err">{result.stderr}</pre>}

              {!running && result && !result.stdout && !result.stderr && !result.timedOut && (
                <div className="no-output">（程序没有产生输出）</div>
              )}
            </div>

            {running && (
              <form
                className="term-input"
                onSubmit={(event) => {
                  event.preventDefault();
                  sendLine();
                }}
              >
                <span className="term-caret">›</span>
                <input
                  className="term-field"
                  value={lineInput}
                  onChange={(event) => setLineInput(event.target.value)}
                  placeholder="程序等待输入时，在这里键入并回车"
                  autoComplete="off"
                  spellCheck={false}
                  autoFocus
                  aria-label="实时标准输入"
                />
                <button type="submit" className="term-send">
                  发送
                </button>
              </form>
            )}
          </section>
        </aside>
        </main>
      ) : (
        <PromptLibrary onToast={showToast} />
      )}

      {shareOpen && (
        <div
          className="modal-overlay"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) setShareOpen(false);
          }}
        >
          <div className="prompt-dialog share-dialog">
            <div className="dialog-head">
              <h3>分享代码</h3>
              <button
                type="button"
                className="icon-btn"
                onClick={() => setShareOpen(false)}
                aria-label="关闭"
              >
                <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                  <path d="M6 6l12 12M18 6L6 18" />
                </svg>
              </button>
            </div>
            <div className="dialog-body">
              <label className="field">
                <span>分享链接</span>
                <input
                  value={shareLink}
                  readOnly
                  onFocus={(event) => event.target.select()}
                  aria-label="分享链接"
                />
              </label>
              <p className="share-tip">
                打开链接即可载入 {activeMeta?.name || '该语言'} 的代码与标准输入。
              </p>
            </div>
            <div className="dialog-foot">
              <span className="dialog-hint">
                {activeMeta?.fileName || '代码'} · {(codes[activeId] || '').length} 字符
              </span>
              <div className="dialog-actions">
                <button type="button" className="ghost-btn" onClick={() => setShareOpen(false)}>
                  关闭
                </button>
                <button type="button" className="run-btn" onClick={copyShareLink}>
                  复制链接
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {toast && <div className="toast">{toast}</div>}
    </div>
  );
}
