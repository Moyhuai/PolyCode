export const SNIPPETS = {
  javascript: `// 点击「运行代码」或按 Ctrl / Cmd + Enter
const fib = (n) => (n < 2 ? n : fib(n - 1) + fib(n - 2));

const values = Array.from({ length: 12 }, (_, i) => fib(i));
console.log('斐波那契数列：');
console.log(values.join('  '));

const squares = values
  .filter((x) => x % 2 === 0)
  .map((x) => x * x);

console.log('其中偶数的平方：', squares.join(', '));
`,

  typescript: `interface Point {
  x: number;
  y: number;
}

const distance = (a: Point, b: Point): number =>
  Math.hypot(a.x - b.x, a.y - b.y);

const points: Point[] = [
  { x: 0, y: 0 },
  { x: 3, y: 4 },
  { x: 8, y: 6 },
];

points.slice(1).forEach((point, index) => {
  console.log(\`距离 \${index + 1}：\${distance(points[0], point).toFixed(2)}\`);
});
`,

  python: `from collections import Counter

text = "the quick brown fox jumps over the lazy dog"
counts = Counter(text.replace(" ", ""))

print("字符出现频率 Top 6：")
for char, times in counts.most_common(6):
    bar = "█" * times
    print(f"  {char}  {bar} {times}")

print("\\n最长单词：", max(text.split(), key=len))
`,

  c: `#include <stdio.h>

int is_prime(int n) {
    if (n < 2) return 0;
    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0) return 0;
    }
    return 1;
}

int main(void) {
    int found = 0;
    printf("前 10 个质数：");
    for (int n = 2; found < 10; n++) {
        if (is_prime(n)) {
            printf("%d ", n);
            found++;
        }
    }
    printf("\\n");
    return 0;
}
`,

  cpp: `#include <algorithm>
#include <iostream>
#include <vector>

int main() {
    std::vector<int> nums{42, 7, 19, 88, 3, 56, 21};

    std::sort(nums.begin(), nums.end());

    std::cout << "升序排列：";
    for (int n : nums) std::cout << n << ' ';
    std::cout << "\\n最大值：" << nums.back() << std::endl;

    return 0;
}
`,

  rust: `fn is_prime(n: u64) -> bool {
    n >= 2 && (2..=((n as f64).sqrt() as u64)).all(|d| n % d != 0)
}

fn main() {
    let primes: Vec<u64> = (2..)
        .filter(|n| is_prime(*n))
        .take(10)
        .collect();

    println!("前 10 个质数：{:?}", primes);
    println!("它们的和：{}", primes.iter().sum::<u64>());
}
`,

  java: `public class Main {
    static boolean isPrime(int n) {
        if (n < 2) return false;
        for (int i = 2; i * i <= n; i++) {
            if (n % i == 0) return false;
        }
        return true;
    }

    public static void main(String[] args) {
        StringBuilder result = new StringBuilder();
        int found = 0;
        for (int n = 2; found < 10; n++) {
            if (isPrime(n)) {
                result.append(n).append(' ');
                found++;
            }
        }
        System.out.println("前 10 个质数：" + result);
    }
}
`,

  go: `package main

import (
	"fmt"
	"strings"
)

func main() {
	languages := []string{"go", "rust", "java", "python"}

	upper := make([]string, len(languages))
	for i, name := range languages {
		upper[i] = strings.ToUpper(name)
	}

	fmt.Println("语言列表：", strings.Join(upper, " | "))
	fmt.Printf("共 %d 种\\n", len(upper))
}
`,

  php: `<?php
$scores = [
    'Alice' => 92,
    'Bob'   => 78,
    'Carol' => 85,
    'Dave'  => 96,
];

arsort($scores);

echo "成绩排名：\\n";
$rank = 1;
foreach ($scores as $name => $score) {
    printf("  %d. %-6s %d\\n", $rank++, $name, $score);
}
`,

  ruby: `words = %w[ruby python javascript rust go]

groups = words.group_by(&:length).sort

groups.each do |length, list|
  puts "#{length} 个字母：#{list.join(', ')}"
end

puts "平均长度：#{words.sum(&:length).to_f / words.size}"
`,
};

export const DEFAULT_CODE =
  '# 在此输入程序的标准输入（可选）\n# 例如：输入多行数据后，程序可通过 stdin 读取\n';
